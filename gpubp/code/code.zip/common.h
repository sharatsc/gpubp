#include <stdio.h>
#include <stdlib.h>

#ifndef __COMMON_H__
#define __COMMON_H__

#define MAX_PARENTS  8
#define MAX_CHILDREN 16
#define MAX_STATES   16
#define MAX_NODES    32

#define TOGPU 0
#define FROMGPU 1

#define MAXPRODUCT 1
#define SUMPRODUCT 0

typedef struct __tagnode
{
  int size; /*number of states*/
  int npar; /*number of parents*/
  int parents[MAX_PARENTS]; 
  int nchild;
  int children[MAX_CHILDREN];
  int observed;
  float *M; 
  int   Msize;
  float lambda[MAX_STATES];
  float pi[MAX_STATES];
  float bel[MAX_STATES];
}node;


typedef struct __tagmessage
{
  float lambda [MAX_NODES][MAX_PARENTS][MAX_STATES];
  float pi     [MAX_NODES][MAX_CHILDREN][MAX_STATES];
}message;


typedef struct __tagnetwork
{
  int num;
  int sizes[MAX_NODES];
  node var[MAX_NODES];
  int dag[MAX_NODES][MAX_PARENTS];
}network;

typedef struct __tagstate
{
  float value[MAX_NODES][MAX_STATES];
  int   sizes[MAX_NODES];
  int   num;
}state;

typedef struct __tagframe
{
  float lambda[MAX_STATES];
  float pi[MAX_STATES]; 
  float bel[MAX_STATES];
  int cidx[MAX_CHILDREN];
  int pidx[MAX_PARENTS];
  int psizes[MAX_PARENTS];
  int uidx[MAX_PARENTS];
  float term[MAX_STATES][MAX_STATES];
  float py[MAX_STATES];
  int  msize;
}frame;

#endif 
